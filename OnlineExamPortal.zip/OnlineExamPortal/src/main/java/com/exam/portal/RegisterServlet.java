package com.exam.portal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {
	String url=null;
	String un =null;
	String pwd=null;
	Connection con=null;
	PreparedStatement stmt =null;
	
	
	@override
	public void init(ServletConfig config) throws ServletException {
		  ServletContext scont=config.getServletContext();
		  url=scont.getInitParameter("url");
		  un=scont.getInitParameter("un");
		  pwd=scont.getInitParameter("pwd");
		  try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con =DriverManager.getConnection(url,un,pwd);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.print("Error occured here.....");
		}
		  

		  
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		String name=req.getParameter("fullname");
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		
		String query ="insert into user(name,email,password) values(?,?,?)";
		try {
			stmt =con.prepareStatement(query);
			stmt.setString(1, name);
			stmt.setString(2, email);
			stmt.setString(3, password);
			int res=stmt.executeUpdate();
			if(res>0) {
				resp.getWriter().print("login page");
				resp.sendRedirect("login.html");
			}
			else {
				resp.getWriter().println("Invalid details");
			}


			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	
	       
    
	
}
