package com.exam.portal;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class examServlet
 */
@WebServlet("/examServlet")
public class examServlet extends HttpServlet {
	Connection con =null;
	String url=null;
	String un=null;
	String pwd=null;
	@Override
	public void init(ServletConfig config) throws ServletException {
		  ServletContext scont=config.getServletContext();
		  url=scont.getInitParameter("url");
		  un=scont.getInitParameter("un");
		  pwd=scont.getInitParameter("pwd");
		  try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con =DriverManager.getConnection(url,un,pwd);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.print("Error occured here.....");
		}
		 		}
	
	
	
	@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse resp) 
				throws ServletException, IOException {
		
		List<Question> ques=new ArrayList<>();
		
		String query ="select * from questions";
		try {
			PreparedStatement stmt=con.prepareStatement(query);
			ResultSet res=stmt.executeQuery();
			while(res.next()) {
				Question q=new Question();
				q.setId(res.getInt("Q_id"));
				q.setText(res.getString("question"));
				q.setOptionA(res.getString("option_a"));
				q.setOptionB(res.getString("option_b"));
				q.setOptionC(res.getString("option_c"));
				q.setOptionD(res.getString("option_d"));
				q.setCorrectOption(res.getString("Correct_option"));
				
				ques.add(q);
				
			}
			request.setAttribute("ques", ques);
			request.getRequestDispatcher("exam.jsp").forward(request, resp);;
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			// TODO Auto-generated method stub
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}