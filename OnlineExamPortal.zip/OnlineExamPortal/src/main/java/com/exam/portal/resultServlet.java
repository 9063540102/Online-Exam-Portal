package com.exam.portal;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/resultServlet")
public class resultServlet extends HttpServlet {
       
	Connection con =null;
	String url=null;
	String un=null;
	String pwd=null;
	@Override
	public void init(ServletConfig config) throws ServletException {
		  ServletContext scont=config.getServletContext();
		  url=scont.getInitParameter("url");
		  un=scont.getInitParameter("un");
		  pwd=scont.getInitParameter("pwd");
		  try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con =DriverManager.getConnection(url,un,pwd);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.print("Error occured here.....");
		}
		 		}
@Override
protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
		throws ServletException, IOException {
	Map<Integer,String> h=new HashMap<>();
	List<Question> questions=new ArrayList<>();
	HttpSession session=req.getSession(false);
	int total=0,score=0;
	
	try {
		if(session==null||session.getAttribute("user_id")==null) {
			resp.sendRedirect("login.html");
		}
		int u_id=(int)session.getAttribute("user_id");
		String query="select q_id,Correct_option from questions";		
	PreparedStatement pstmt=con.prepareStatement(query);
	ResultSet res=pstmt.executeQuery();
	while(res.next()) {
		Integer q_i=res.getInt("q_id");
		String correct_option=res.getString("Correct_option");
		String user_option=req.getParameter(res.getString("q_id"));
		resp.getWriter().println(user_option);
		h.put(q_i,user_option);
		if(user_option.equalsIgnoreCase(correct_option)) {
			score++;
		}
		total++;	
	}
	resp.getWriter().println(score);
	String query2="insert into results(user_id,score,total_questions) values(?,?,?)";
	PreparedStatement pstmt2=con.prepareStatement(query2);
	pstmt2.setInt(1, u_id);
	pstmt2.setInt(2, score);
	pstmt2.setInt(3, total);
	pstmt2.executeUpdate();
	session.setAttribute("score", score);
	session.setAttribute("total", total);
	
	
	String query3="select * from questions";
	 pstmt2 =con.prepareStatement(query3);
	 ResultSet res2=pstmt2.executeQuery();
	 
	 
	 while(res2.next()) {
		 Question q=new Question();
		q.setId(res2.getInt("q_id"));
		q.setText(res2.getString("question"));
		q.setOptionA(res2.getString("option_a"));
		q.setOptionB(res2.getString("option_b"));
		q.setOptionC(res2.getString("option_c"));
		q.setOptionD(res2.getString("option_a"));
		q.setCorrectOption(res2.getString("Correct_option"));	
		questions.add(q);
	}
	 
	 session.setAttribute("questions", questions);
	 session.setAttribute("user_options", h);
	 resp.sendRedirect("result.jsp");
	
	
	
	
	
	
	
	}
	
	catch(Exception e) {
		
	}

	
	
	
	
}







}