package com.exam.portal;

public @interface override {

}
