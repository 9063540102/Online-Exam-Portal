package com.exam.portal;
import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//import com.mysql.cj.xdevapi.Statement;

public class LoginServlet extends HttpServlet {
	
	Connection con =null;
	String url=null;
	String un=null;
	String pwd=null;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		  ServletContext scont=config.getServletContext();
		  url=scont.getInitParameter("url");
		  un=scont.getInitParameter("un");
		  pwd=scont.getInitParameter("pwd");
		  try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con =DriverManager.getConnection(url,un,pwd);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.print("Error occured here.....");
		}
		  

		  
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
			String em =req.getParameter("email");
			String pwd =req.getParameter("Password");
			String query ="select * from user where email=? AND password=?";
			try {
				PreparedStatement pstmt =con.prepareStatement(query);
				pstmt.setString(1, em);
				pstmt.setString(2, pwd);
				ResultSet res =pstmt.executeQuery();
				if(res.next()) {
				HttpSession session =req.getSession();
				session.setAttribute("user_id", res.getInt("id"));
				session.setAttribute("user_name", res.getString("name"));
				 
					resp.sendRedirect("examServlet");
				}else {
					resp.getWriter().println("invalid login details");
				}
			
				
				
				

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				
	}
}
